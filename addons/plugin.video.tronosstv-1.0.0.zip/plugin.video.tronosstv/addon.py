import sys
import urllib.parse
import re
import xbmcplugin
import xbmcgui
import xbmc
import requests
import xbmcvfs
import os
import json
import base64
import hashlib
import hmac

addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

ICON_PATH = xbmcvfs.translatePath('special://home/addons/plugin.video.tronosstv/icono.png')
FANART_PATH = xbmcvfs.translatePath('special://home/addons/plugin.video.tronosstv/resources/fanart.jpg')
CREDENTIALS_FILE = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.tronosstv/credentials.json')
SECRET_KEY = "c0mpl3xS3cur3K3y"  # Clave secreta para ofuscar

ACESTREAM_URL = "https://ipfs.io/ipns/elcano.top"

def obfuscate_credentials(username, password):
    combined = f"{username}:{password}".encode('utf-8')
    hmac_digest = hmac.new(SECRET_KEY.encode('utf-8'), combined, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(hmac_digest).decode('utf-8')

def save_credentials(username, password):
    os.makedirs(os.path.dirname(CREDENTIALS_FILE), exist_ok=True)
    obfuscated = obfuscate_credentials(username, password)
    with open(CREDENTIALS_FILE, 'w') as f:
        json.dump({"auth": obfuscated}, f)

def load_credentials():
    if os.path.exists(CREDENTIALS_FILE):
        with open(CREDENTIALS_FILE, 'r') as f:
            data = json.load(f)
            return data.get("auth")
    return None

def prompt_for_credentials():
    keyboard = xbmcgui.Dialog()
    username = keyboard.input("Introduce el usuario", type=xbmcgui.INPUT_ALPHANUM)
    if not username:
        return None, None
    password = keyboard.input("Introduce la contraseña", type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.PASSWORD_VERIFY)
    if not password:
        return None, None
    return username, password

def check_credentials():
    stored_auth = load_credentials()
    correct_auth = obfuscate_credentials("tronoss", "tronoss1234")
    if stored_auth == correct_auth:
        return True

    xbmcgui.Dialog().notification("Inicio de sesión", "Por favor, inicia sesión", xbmcgui.NOTIFICATION_INFO)
    while True:
        username, password = prompt_for_credentials()
        if obfuscate_credentials(username, password) == correct_auth:
            save_credentials(username, password)
            xbmcgui.Dialog().notification("Éxito", "Inicio de sesión correcto", xbmcgui.NOTIFICATION_INFO)
            return True
        else:
            xbmcgui.Dialog().notification("Error", "Usuario o contraseña incorrectos", xbmcgui.NOTIFICATION_ERROR)

def get_page_content(url):
    try:
        response = requests.get(url)
        response.encoding = 'utf-8'
        if response.status_code == 200:
            return response.text
        else:
            xbmcgui.Dialog().notification("Error", f"HTTP {response.status_code}", xbmcgui.NOTIFICATION_ERROR)
            return ""
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return ""

def extract_acestream_links(content):
    channels = []
    pattern_full = r'"name":\s*"([^\"]+)".*?"url":\s*"acestream://([a-fA-F0-9]+)"'
    pattern_partial = r'(.*?)\s*acestream://(?:\s|$)'
    matches_full = re.findall(pattern_full, content)
    for name, channel_id in matches_full:
        channels.append((name.strip(), channel_id.strip()))
    
    lines = content.splitlines()
    for line in lines:
        line = line.strip()
        if "acestream://" in line and not re.search(r'acestream://[a-fA-F0-9]+', line):
            name_match = re.match(r'(.*?)\s*acestream://', line)
            if name_match:
                name = name_match.group(1).strip()
                channels.append((name, ""))
    return sorted(channels, key=lambda x: x[0].lower())

def build_url(query):
    return f"{base_url}?{urllib.parse.urlencode(query)}"

def list_channels():
    content = get_page_content(ACESTREAM_URL)
    if not content:
        xbmcplugin.endOfDirectory(addon_handle)
        return

    channels = extract_acestream_links(content)
    if not channels:
        xbmcgui.Dialog().notification("Error", "No se encontraron canales", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    for name, channel_id in channels:
        url = build_url({"action": "play", "id": channel_id}) if channel_id else ""
        list_item = xbmcgui.ListItem(name)
        list_item.setInfo("video", {"title": name})
        list_item.setProperty("IsPlayable", "true")
        list_item.setArt({
            'icon': ICON_PATH,
            'thumb': ICON_PATH,
            'fanart': FANART_PATH
        })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)

def play_channel(channel_id):
    if not channel_id:
        xbmcgui.Dialog().notification("Error", "Canal sin ID disponible", xbmcgui.NOTIFICATION_ERROR)
        return

    # Ejecutar Horus a través del plugin
    horus_command = f'RunPlugin("plugin://script.module.horus/?action=play&id={channel_id}")'
    try:
        xbmc.executebuiltin(horus_command)
        xbmcgui.Dialog().notification("Horus", "Reproduciendo en AceStream Engine...", xbmcgui.NOTIFICATION_INFO)
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"No se pudo ejecutar Horus: {e}", xbmcgui.NOTIFICATION_ERROR)

def router(args):
    action = args.get("action", [None])[0]
    channel_id = args.get("id", [None])[0]

    if action == "play" and channel_id:
        play_channel(channel_id)
    else:
        list_channels()

if __name__ == "__main__":
    if check_credentials():
        args = urllib.parse.parse_qs(sys.argv[2][1:])
        router(args)
    else:
        xbmcplugin.endOfDirectory(addon_handle)
