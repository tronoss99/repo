import requests
import os
import xbmcvfs
import xbmc
import xbmcgui
import xbmcaddon

UPDATE_URL = "https://raw.githubusercontent.com/tronoss99/repo/main/main.py"
MAIN_SCRIPT_PATH = xbmcvfs.translatePath('special://home/addons/plugin.video.tronosstv/main.py')

def download_main_script():
    try:
        response = requests.get(UPDATE_URL)
        if response.status_code == 200:
            with open(MAIN_SCRIPT_PATH, 'wb') as f:
                f.write(response.content)
            xbmc.log("main.py actualizado correctamente.", level=xbmc.LOGINFO)
        else:
            xbmc.log(f"No se pudo descargar. HTTP {response.status_code}", level=xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Error al descargar: {e}", level=xbmc.LOGERROR)

def execute_main_script():
    if os.path.exists(MAIN_SCRIPT_PATH):
        try:
            with open(MAIN_SCRIPT_PATH, 'rb') as f:
                exec(compile(f.read(), MAIN_SCRIPT_PATH, 'exec'), globals())
            xbmc.log("Ejecutado correctamente.", level=xbmc.LOGINFO)
        except Exception as e:
            xbmcgui.Dialog().notification("Error", f"No se pudo ejecutar: {e}", xbmcgui.NOTIFICATION_ERROR)
            xbmc.log(f"Error al ejecutar: {e}", level=xbmc.LOGERROR)
    else:
        xbmcgui.Dialog().notification("Error", "Archivo no encontrado", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log("Archivo no encontrado.", level=xbmc.LOGERROR)

if __name__ == "__main__":
    addon = xbmcaddon.Addon(id='plugin.video.tronosstv')

    tronosstv_menu_view = addon.getSetting("tronosstv_menu_view") or "80"
    main_menu_view = addon.getSetting("main_menu_view") or "50"
    events_list_view = addon.getSetting("events_list_view") or "50"

    globals()['tronosstv_menu_view'] = tronosstv_menu_view
    globals()['main_menu_view'] = main_menu_view
    globals()['events_list_view'] = events_list_view

    download_main_script() 
    execute_main_script()
