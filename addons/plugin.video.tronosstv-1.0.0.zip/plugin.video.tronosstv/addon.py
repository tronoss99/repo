import requests
import os
import xbmcvfs
import xbmc
import xbmcgui
import hashlib
import json

UPDATE_URL = "https://raw.githubusercontent.com/tronoss99/repo/main/main.py"
MAIN_SCRIPT_PATH = xbmcvfs.translatePath('special://home/addons/plugin.video.tronosstv/main.py')

def get_remote_main_hash():
    try:
        response = requests.get(UPDATE_URL)
        if response.status_code == 200:
            remote_content = response.content
            return hashlib.sha256(remote_content).hexdigest()
    except Exception as e:
        xbmc.log(f"Error al obtener hash remoto: {e}", level=xbmc.LOGERROR)
    return None

def get_local_main_hash():
    try:
        if os.path.exists(MAIN_SCRIPT_PATH):
            with open(MAIN_SCRIPT_PATH, 'rb') as f:
                local_content = f.read()
                return hashlib.sha256(local_content).hexdigest()
    except Exception as e:
        xbmc.log(f"Error al obtener hash local: {e}", level=xbmc.LOGERROR)
    return None

def download_main_script():
    remote_hash = get_remote_main_hash()
    if not remote_hash:
        xbmc.log("No se pudo obtener el hash remoto de main.py.", level=xbmc.LOGERROR)
        return
    local_hash = get_local_main_hash()
    if remote_hash != local_hash:
        try:
            response = requests.get(UPDATE_URL)
            if response.status_code == 200:
                with open(MAIN_SCRIPT_PATH, 'wb') as f:
                    f.write(response.content)
                xbmc.log("main.py actualizado correctamente.", level=xbmc.LOGINFO)
            else:
                xbmc.log(f"HTTP {response.status_code} al intentar actualizar main.py.", level=xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"Error al descargar main.py: {e}", level=xbmc.LOGERROR)
    else:
        xbmc.log("main.py ya está actualizado. No se requiere descarga.", level=xbmc.LOGINFO)

def execute_main_script():
    if os.path.exists(MAIN_SCRIPT_PATH):
        try:
            with open(MAIN_SCRIPT_PATH, 'rb') as f:
                exec(compile(f.read(), MAIN_SCRIPT_PATH, 'exec'), globals())
        except Exception as e:
            xbmc.log(f"Error al ejecutar main.py: {e}", level=xbmc.LOGERROR)
    else:
        xbmc.log("Archivo main.py no encontrado.", level=xbmc.LOGERROR)

if __name__ == "__main__":
    download_main_script()
    execute_main_script()
